# Bar numérique

Application de gestion du bar de la MDL

## Fonctionnalités

// *TODO*

## Licence

// *TODO*

## Documentation

// *TODO*

## Open-source

// *TODO*

## Idées futures

* Utiliser un menu burger -> menu peu utilisé   

## Consignes

* Le code réutilisé (partiellement ou complètement) doit être attribué à son auteur
* PEP8
